<?php
require_once(dirname(__FILE__)."/../../../wp-blog-header.php");
require_once(dirname(__FILE__)."/create_table_functions.php");
header('HTTP/1.1 200 OK');
global $wpdb;

$cat_nos = isset($_REQUEST['cat_nos']) ? $_REQUEST['cat_nos'] : '';
$title = isset($_REQUEST['title']) ? $_REQUEST['title'] : '';
$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';
$link_arr = isset($_REQUEST['link']) ? $_REQUEST['link'] : '';
$datetable = isset($_REQUEST['datetable']) ? $_REQUEST['datetable'] : '';
$cat_nos=rtrim($cat_nos, ",");
$link_arr=rtrim($link_arr, ",");
//$group_id_arr = isset($_REQUEST['group_id']) ? $_REQUEST['group_id'] : '';

if($action=='insert'){//添加
	if(!empty($cat_nos)){
		$miss=$wpdb->get_var(sprintf("SELECT count(*) FROM `wp_create_table` where title='%s'",$title));
		if($miss==0){
		$val=sprintf(" ('%s','%s','%s') ",$cat_nos, $title,$datetable);
		$sql = sprintf("INSERT INTO `wp_create_table` (`content`,`title`,`datetable`) values %s",$val);
		$result = $wpdb->query($sql);// or $wpdb->print_error();

		if(!empty($link_arr)){
		if($datetable=='_cs_misc_product'){
			$sort='catalog';
			$url='url';
		}else if($datetable=='vector'){
			$sort='vector_name';
			$url='vector_link';
		}
		$arr2=explode(',', $link_arr);
		foreach ($arr2 as $arr) {
			$arr3=explode('|', $arr);
			$sql2 = sprintf("UPDATE %s SET %s='%s' WHERE %s='%s';",$datetable,$url,$arr3[1],$sort,$arr3[0]);
			$result2 = $wpdb->query($sql2);
		}
		}

		if( $result == true){
			echo json_encode(array('status'=>'true', 'action'=>'insert', 'notice'=>"<strong>Use this short tag in the post</strong>: <input type='text' class='shortcode2' value=\"[create_table title='".$title."']\" />" ,'msg'=>'Data added.', 'label'=>"<strong>Use this short tag in the post</strong>: <input type='text' class='shortcode2' value=\"[create_table title='".$title."']\" />" ,'msg'=>'Data added.'));
		}else{//false
			echo json_encode(array('status'=>'false','action'=>'insert', 'notice'=>'Products Add Fail. Please Retry Again.','msg'=>''));
		}
		}else{
			echo json_encode(array('status'=>'false','action'=>'insert', 'notice'=>'Products Add Fail. Duplicate Table Title.'.$title,'msg'=>''));
		}
	}else{//提交的catalog是空的
		echo json_encode(array('status'=>'false','action'=>'insert', 'notice'=>'No Content Submit,Nothing to do.','msg'=>''));
	}
	
}elseif($action=='update'){//更新
	$arr=explode(',', $title);
	if(count($arr)==2){
		$sql = sprintf("UPDATE wp_create_table SET content='%s',title='%s' WHERE title='%s';",$cat_nos,$arr[0],$arr[1]);
	}else{
		$sql = sprintf("UPDATE wp_create_table SET content='%s' WHERE title='%s';",$cat_nos,$title);
	}
	$result = $wpdb->query($sql);

	if(!empty($link_arr)){
		if($datetable=='_cs_misc_product'){
			$sort='catalog';
			$url='url';
		}else if($datetable=='vector'){
			$sort='vector_name';
			$url='vector_link';
		}
		$arr2=explode(',', $link_arr);
		foreach ($arr2 as $arr) {
			$arr3=explode('|', $arr);
			$sql2 = sprintf("UPDATE %s SET %s='%s' WHERE %s='%s';",$datetable,$url,$arr3[1],$sort,$arr3[0]);
			$result2 = $wpdb->query($sql2);
		}
	}
	
	
	if( $result !== false ){
		echo json_encode(array('status'=>'true','action'=>'update', 'notice'=>'Products Update.'));
	}else{
		echo json_encode(array('status'=>'false','action'=>'update', 'notice'=>'Try again.'));
	}
}elseif($action=='delete'){//删除
	$sql = sprintf("DELETE FROM `wp_create_table` WHERE title='%s'",$title);
	$result = $wpdb->query($sql);
	if( $result !== false ){
		echo json_encode(array('status'=>'true','action'=>'delete', 'notice'=>'Products Delete.'));
	}else{
		echo json_encode(array('status'=>'false','action'=>'delete', 'notice'=>'Try again.'));
	}
}

