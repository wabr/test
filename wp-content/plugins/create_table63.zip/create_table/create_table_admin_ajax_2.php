<?php
require_once(dirname(__FILE__)."/../../../wp-blog-header.php");
require_once(dirname(__FILE__)."/create_table_functions.php");
header('HTTP/1.1 200 OK');
global $wpdb;

if($_REQUEST['action']=='add'){
$title = date("ymd.His");
ob_start();
?>
<input type="submit" value="Save" class="save" />
select datetable:
<select class="datetable" name="datetable" id="datetable">
	<option  value="_cs_misc_product">misc</option>
	<option value="vector">vector</option>
</select>&emsp; &emsp; &emsp; 
title:
<input type="hidden" name="title2" value="<?php echo $title; ?>" />
<input type="hidden" name="action" value="insert" />
<input type="text" name="title1">&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
search:
<input type="text" placeholder="catalog" name="search" id="search"/>
<button class='search' type="button"><span class="dashicons dashicons-search"></span></button>
<div class="list_catalog_box">
	<?php //echo list_misc_product_list($wpdb,1);?>
	<?php echo create_table_list($wpdb);?>
</div>
<input type="submit" value="Save" class="save" />
<?php
$output = ob_get_clean();
echo json_encode(array('notice' => "<strong>Use this short tag in the post</strong>: <input type='text' class='shortcode2' value=\"[create_table title='".$title."']\" />",'msg'=>$output));

}elseif($_REQUEST['action']=='update' AND $_REQUEST['title']!=''){
	$title  =  $_REQUEST['title'];
ob_start();
?>
<input type="submit" value="Save" class="save" />
<input type="button" value="Delete" data-title="<?php echo $title;?>" class="delete" />
<input type="hidden" name="title2" value="<?php echo $title; ?>" />
<input type="hidden" name="action" value="update" />
&emsp; &emsp;&emsp;title:
<input type="text" name="title1">&emsp; &emsp; &emsp; &emsp; &emsp;
search:
<input type="text" placeholder="catalog" name="search" id="search"/>
<button class="search" type="button"><span class="dashicons dashicons-search"></span></button>
<div class="list_catalog_box">
	<?php
	echo create_table_list($wpdb,$title);
	?>
</div>
<input type="submit" value="Save" class="save" />
<input type="button" value="Delete" data-title="<?php echo $title;?>" class="delete" />
<?php
$output = ob_get_clean();
$product=$wpdb->get_results(sprintf("SELECT * FROM `wp_create_table` where title='%s'",$title));
echo json_encode(array('notice' => "<strong>Use this short tag in the post</strong>: <input type='text' class='shortcode2' value=\"[create_table title='".$title."']\" />",'datetable'=>$product[0]->datetable,'cat_nos'=>$product[0]->content,'msg'=>$output));

}else if($_REQUEST['action']=='table'){
$title=empty($_REQUEST['title'])?'':$_REQUEST['title'];
$page=empty($_REQUEST['page'])?1:$_REQUEST['page'];
$datetable=empty($_REQUEST['datetable'])?'_cs_misc_product':$_REQUEST['datetable'];
$search=empty($_REQUEST['search'])?'':$_REQUEST['search'];
ob_start();
echo create_table_list($wpdb,$title,$page,$datetable,$search);
$output = ob_get_clean();
echo json_encode($output);

}else if($_REQUEST['action']=='dt1'){
	$sql=$_REQUEST['datetable']==''?'':"where datetable='".$_REQUEST['datetable']."'";
	$label=$wpdb->get_results(sprintf("SELECT title FROM `wp_create_table` %s",$sql));
	ob_start();
	if(!empty($label)){
		foreach ($label as $la) {
		?>
<input type="button" class="update" data-title="<?php echo $la->title;?>" value="Update : <?php echo $la->title;?>" />
		<?php
	}
	}else{
		echo '';
	}
	$output = ob_get_clean();
	echo json_encode($output);

}else if($_REQUEST['action']=='search_la'){
	$sql="where ";
	$sql1="title like '%{$_REQUEST['search_la']}%' or content like '%{$_REQUEST['search_la']}%'";
	$sql2=$_REQUEST['datetable']==''?'':" and datetable='".$_REQUEST['datetable']."'";
	$sql.=$sql2==''?$sql1:"(".$sql1.")".$sql2;
	$label=$wpdb->get_results(sprintf("SELECT title FROM `wp_create_table` %s",$sql));
	ob_start();
	if(!empty($label)){
		foreach ($label as $la) {
		?>
<input type="button" class="update" data-title="<?php echo $la->title;?>" value="Update : <?php echo $la->title;?>" />
		<?php
	}
	}else{
		echo '';
	}
	$output = ob_get_clean();
	echo json_encode($output);
}
?>