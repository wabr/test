<?php
require_once(dirname(__FILE__)."/../../../wp-blog-header.php");
require_once(dirname(__FILE__)."/create_table_functions.php");
header('HTTP/1.1 200 OK');
global $wpdb;
function get_table_list($page=1,$where=''){
	$cou=$wpdb->get_var(sprintf("select count(*) from wp_create_table %s",$where));
	$star=($page-1)*10;
	$tables=$wpdb->get_results(sprintf("select title,creat_table from wp_create_table %s limit %s,10",$where,$star));
	if(!empty($table)){
		foreach ($tables as $table) {
		$str1.="<tr>
			<td class='tal fr'><input name='select_all' type='checkbox' class='select_all' /></td>
			<td class='tal se'>".$table->tile."</td>
			<td class='tal se'>".$table->create_date."</td>
			<td class='tal th'>[create_table title=".$table->tile."]</td>
			</tr>"
		}
	}
	if($cou>10){
		$return_string .= '';
		if($page>3){
			$str2.="<span class='ellipsis'>…</span>";
		}
		if($page<=2){
			$str2.="<input type='button'  class='jump ' data-page='2' value='2'/><input type='button'  class='jump' data-page='3' value='3'/>";
		}else if($page>=$maxpage-1){
			$str2.="<input type='button' class='jump' data-page='".($maxpage-2)."' value='".($maxpage-2)."'/><input type='button' class='jump' data-page='".($maxpage-1)."' value='".($maxpage-1)."'/>";
		}else{
			$str2="<input type='button' class='jump' data-page='".($page-1)."' value='".($page-1)."'/><input type='button' class='jump' data-page='".$page."' value='".$page."'/><input type='button' class='jump' data-page='".($page+1)."' value='".($page+1)."'/>";
		}
		if($page<$maxpage-2){
			$str2.="<span class='ellipsis'>…</span>";
		}
		$str2 .= "<input type='button' class='jump current' data-page='1' value='1'/>".$str2."<input type='button' class='jump' data-page='".$maxpage."' value='".$maxpage."'/>";
	}
	$arr[0]=$str1;
	$arr[1]=$str2;
	$arr[3]=$cou;
	return $arr;
}
if(!empty($_POST['page'])||!empty($_POST['where'])){
	$page=$_POST['page']==''?1:$_POST['page'];
	$where=$_POST['where']==''?'':$_POST['where'];
	$arr=get_table_list($page,$where);
	echo json_encode($arr);
	exit;
}
$arr=get_table_list();
$time=$wpdb->get_results("select YEAR(create_date) as year,MONTH(create_date) as mon from wp_create_table group by year,mon");
?>
<h1>Table List</h1>
<a href="/wp-admin/admin.php?page=creat_table" class="page-title-action">Add New</a>
search label:
<input type="text" placeholder="title or catalog" name="search_la" id="search_la"/>
<button class='search_la' type="button"><span class="dashicons dashicons-search"></span></button>
<select class="sel" id="bulk1">
	<option value="">Bulk actions</option>
	<option value="delete">delete</option>
</select>
<input type="button" id="buck2" value="Apply" />
<select class="sel" id="dt1">
	<option value="">Select datetable</option>
	<option value="_cs_misc_product">misc</option>
	<option value="vector">vector</option>
</select>
<select class="sel" id="time">
	<option value="">All date</option>
	<?php
	foreach ($time as $key => $value) {
		echo '<option value="'.$value['year']."-".$value['mon'].'">'.$value['year']."-".$value['mon'].'</option>';
	}
	?>
</select>
<span><?php echo $arr[3]; ?> tables</span>
<table>
<thead>
	<tr>
		<th class='tal fr'><input name='select_all' type='checkbox' class='select_all' /></th>
		<th class='tal se'>Title</th>
		<th class='tal se'>Date</th>
		<th class='tal th'>Shortcode</th>
	</tr>
</thead>
<tfoot>
	<tr>
		<th class='tal fr'><input name='select_all' type='checkbox' class='select_all' /></th>
		<th class='tal se'>Title</th>
		<th class='tal se'>Date</th>
		<th class='tal th'>Shortcode</th>
		</tr>
</tfoot>
<tbody id='table'>
<?php if(!empty($arr[0])){
		echo $arr[0];
	  }else{
	  	echo 'no date';
	  }?>
</tbody>
</table>
<div id='jump'>
<?php if(!empty($arr[1])){
		echo $arr[1];
	}?>
</div>
<script type="text/javascript">
jQuery(document).ready(function($){
	$("#dt1").live('change',function(){
		var dt1=$("#dt1").val();
		where='where datetable='+dt1;
		search_la=$("input[name=search_la]").val()==''?'':$("input[name=search_la]").val();
		if(search_la!=''){
			where+="and (content like '%"+search_la+"%' or title like '%"+search_la+"%')";
		}
		$.ajax({
			url: "<?php echo WP_PLUGIN_URL.'/'.dirname(plugin_basename(__FILE__)).'/table_list.php';?>",
			type:"POST",
			async:true,
			dataType:"json",
			data:"where="+where,
			beforeSend:function(){
				$(".table").html("Loading...");
			},
			success:function(msg){
				$(".table").html("").append(msg[0]).show();
				$(".jump").html("").append(msg[1]).show();
			}
		});
	});
	$("#time").live('change',function(){
			time=split($("#time").val());
			where='where YEAR(create_date)='+time[0]+'and MONTH(create_date)='+time[1];
			search_la=$("input[name=search_la]").val()==''?'':$("input[name=search_la]").val();
			if(search_la!=''){
				where+="and (content like '%"+search_la+"%' or title like '%"+search_la+"%')";
			}
		$.ajax({
			url: "<?php echo WP_PLUGIN_URL.'/'.dirname(plugin_basename(__FILE__)).'/table_list.php';?>",
			type:"POST",
			async:true,
			dataType:"json",
			data:"where="+where,
			beforeSend:function(){
				$(".table").html("Loading...");
			},
			success:function(msg){
				$(".table").html("").append(msg[0]).show();
				$(".jump").html("").append(msg[1]).show();
			}
		});
	});
	$(".s_label .search_la").click(function(){
		var search_la=$("input[name=search_la]").val();
		where="where content like '%"+search_la+"%' or title like '%"+search_la+"%'";
		$.ajax({
			url: "<?php echo WP_PLUGIN_URL.'/'.dirname(plugin_basename(__FILE__)).'/table_list.php';?>",
			type:"POST",
			async:true,
			dataType:"json",
			data:"where="+where,
			beforeSend:function(){
				$(".table").html("Loading...");
			},
			success:function(msg){
				$(".table").html("").append(msg[0]).show();
				$(".jump").html("").append(msg[1]).show();
				$("#time").val('');
				$("#dt1").val('');
			}
		});
	});
	$(document).on("click",".page .jump",function(){
		var dt1=$("#dt1").val();
		var dt1=$("#dt1").val();
		var page = $(this).data("page");
		var action = $("input[name=action]").val();
		$.ajax({
			url: "<?php echo WP_PLUGIN_URL.'/'.dirname(plugin_basename(__FILE__)).'/create_table_admin_ajax_2.php';?>",
			type:"POST",
			dataType:"json",
			async:true,
			data:"action=table&page="+page+"&datetable="+datetable+"&title="+title+"&search="+search,
			beforeSend:function(){
				$(".filter_table").html("Loading...");
			},
			success:function(msg){
				$(".filter_table").html("").append(msg).show();//.append(msg);
				$('input[name="cat_nos[]"][type="checkbox"]').each(function(){
					if (str.indexOf($(this).val()) != -1) {
						$(this).prop("checked",true);
					}
				});
				$("input[data-page='"+page+"']").addClass("current").siblings().removeClass("current");
			}
		});
	});
	$(document).on("click",".list_catalog .delete",function(){
		var title = $(this).data("title");
		$.ajax({
			url: "<?php echo WP_PLUGIN_URL.'/'.dirname(plugin_basename(__FILE__)).'/create_table_admin_do.php'?>",
			data:"title="+title+"&action=delete",
			dataType:"json",
			type:"POST",
			success:function(msg){
				if(msg.status=="true"){
					$(".list_catalog").html("");
					$(".shortcode").html(msg.notice);
					$(".update").each(function(){
						if($(this).data("title")==title){
							$(this).remove();
						}
					});
				}else if(msg.status=="false"){
					$(".list_catalog").html("");
					$(".shortcode").html(msg.notice);
				}else{
					console.log("why is here");
				}
			}
		});
		return false;
	});

});
</script>