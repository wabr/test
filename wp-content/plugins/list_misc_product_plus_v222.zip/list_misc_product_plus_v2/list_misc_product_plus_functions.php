<?php
// 如果不存在json_encode这个函数，就加上去
if (!function_exists('json_encode')){
	function json_encode($a=false){
		if (is_null($a)) return 'null';
		if ($a === false) return 'false';
		if ($a === true) return 'true';
		if (is_scalar($a)){
			if (is_float($a)){
				// Always use "." for floats.
				return floatval(str_replace(",", ".", strval($a)));
			}
			if (is_string($a)){
				static $jsonReplaces = array(array("\\", "/", "\n", "\t", "\r", "\b", "\f", '"'), array('\\\\', '\\/', '\\n', '\\t', '\\r', '\\b', '\\f', '\"'));
				return '"' . str_replace($jsonReplaces[0], $jsonReplaces[1], $a) . '"';
			}else
				return $a;
		}
			$isList = true;
			for ($i = 0, reset($a); $i < count($a); $i++, next($a)){
				if (key($a) !== $i){
					$isList = false;
					break;
				}
			}
			$result = array();
			if ($isList){
				foreach ($a as $v) $result[] = json_encode($v);
				return '[' . join(',', $result) . ']';
			}else{
				foreach ($a as $k => $v) $result[] = json_encode($k).':'.json_encode($v);
				return '{' . join(',', $result) . '}';
		}
	}
}

function list_misc_product_list_v2($wpdb,$title=false,$page=1,$datetable='_cs_misc_product'){
		$star=($page-1)*10;
		$cou=0;
		$num=$wpdb->get_var("SELECT count(*) FROM `{$datetable}`");
		$maxpage=$num%10?($num/10+1):($num/10);
		if($datetable=='_cs_misc_product'){
			$sort='catalog';
			$url='url';
		}else if($datetable=='vector'){
			$sort='vector_name';
			$url='vector_link';
		}
		if(!empty($title)){//提供title，列出全部产品，并选中相关项
			$products2=$wpdb->get_results(sprintf("SELECT * FROM `wp_create_table` where title=".$title." ORDER BY catalog ASC"));
			if(!empty($products2)){
				$arr2=explode(',', $products2->catalog);
				$cou=count($arr2);
				foreach ($arr2 as $key => $value) {
					if($key==0){
						$str1="where ".$sort."=".$value;
						$str2="where ".$sort."<>".$value;
					}else{
						$str1.="or ".$sort."=".$value;
						$str2.="and ".$sort."<>".$value;
					}
				}
			}
			if($cou>=($page*10)){
				$products2 = $wpdb->get_results(sprintf("SELECT * FROM `%s` %s ORDER BY %s ASC limit %s,10",$datetable,$str1,$sort,$star));
			}
			else if($cou<($page*10)&&$cou>(($page-1)*10)){
				$products2=$wpdb->get_results(sprintf("SELECT * FROM `%s` %s ORDER BY %s ASC limit %s,10",$datetable,$str1,$sort,$star));
				$end=$page*10-$cou;
				$products = $wpdb->get_results(sprintf("SELECT * FROM `%s` %s ORDER BY %s ASC limit 0,%s",$datetable,$str2,$sort,$end));
			}else{
				$star=$star-$cou;
				$products = $wpdb->get_results(sprintf("SELECT * FROM `%s` %s ORDER BY %s ASC limit %s,10",$datetable,$str2,$sort,$star));
			}
		}else{
			$products = $wpdb->get_results(sprintf("SELECT * FROM `%s` ORDER BY %s ASC limit %s,10",$datetable,$sort,$star));
		}

		$return_string = '';
		$return_string .= sprintf('<table class="filter_table">');
		$return_string .= sprintf("
			<thead>
				<tr>
					<th class=\"tal\"><input name=\"select_all\" type=\"checkbox\" class=\"select_all\" /></th>
					<th class=\"tal\">".$sort."</th>
					<th class=\"tal\">URL</th>
				</tr>
			</thead>
			<tfoot>
				<tr>
					<th class=\"tal\"><input name=\"select_all\" type=\"checkbox\" class=\"select_all\" /></th>
					<th class=\"tal\">".$sort."</th>
					<th class=\"tal\">URL</th>
				</tr>
			</tfoot>
		");
		if(!empty($products2)){
		foreach ($products2 as $product) {
			$return_string .= sprintf("
			<tr>
				<td class=\"tal\">
				<div class=\"catalog\"><div class=\"fl cat_nos\"><input type=\"checkbox\" name=\"cat_nos[]\" value=\"%s\" id=\"%s\" checked=\"checked\"/></div></div>
				</td>
				<td class=\"tal\"><div class=\"fl label\"><label for=\"%s\">%s</label></div></td>
				<td class=\"tal\"><div class=\"fl link\"><span class=\"link_icon\"></span><input type=\"text\" class=\"ln\" name=\"link[%s]\" placeholder=\"%s\" title=\"Double Click To Use This Value\" /></div></td>
			</tr>
			",$product->{$sort},$product->{$sort},$product->{$sort},$product->{$sort},$product->{$sort},$product->{$url});
		}
		}
		if(!empty($products)){
			foreach ($products as $product) {
			$return_string .= sprintf("
			<tr>
				<td class=\"tal\">
				<div class=\"catalog\"><div class=\"fl cat_nos\"><input type=\"checkbox\" name=\"cat_nos[]\" value=\"%s\" id=\"%s\" /></div></div>
				</td>
				<td class=\"tal\"><div class=\"fl label\"><label for=\"%s\">%s</label></div></td>
				<td class=\"tal\"><div class=\"fl link\"><span class=\"link_icon\"></span><input type=\"text\" class=\"ln\" name=\"link[%s]\" placeholder=\"%s\" title=\"Double Click To Use This Value\" /></div></td>
			</tr>
			",$product->{$sort},$product->{$sort},$product->{$sort},$product->{$sort},$product->{$sort},$product->{$url});

		}
		}
		$return_string .= sprintf('</table>');
		if($page<=4){
			$str2="<a class='paginate_button' data-page='1' >1</a><a class='paginate_button' data-page='2' >2</a><a class='paginate_button' data-page='3' >3</a><a class='paginate_button' data-page='4' >4</a><a class='paginate_button' data-page='5' >5</a><span class='ellipsis'>…</span>";
		}else if($page>=$maxpage-4){
			$str2="<a class='paginate_button' data-page='1' >1</a><span class='ellipsis'>…</span></a><a class='paginate_button' data-page='".($page-1)."' >".($page-1)."</a><a class='paginate_button' data-page='".$page."' >".$page."</a><a class='paginate_button' data-page='".($page+1)."' >".($page+1)."</a><span class='ellipsis'>…</span></a><a class='paginate_button' data-page='".$maxpage."' >".$maxpage."</a>";
		}else{
			$str2="<span class='ellipsis'>…</span><a class='paginate_button' data-page='".($maxpage-4)."' >".($maxpage-4)."</a><a class='paginate_button' data-page='".($maxpage-3)."' >".($maxpage-3)."</a><a class='paginate_button' data-page='".($maxpage-2)."' >".($maxpage-2)."</a><a class='paginate_button' data-page='".($maxpage-1)."' >".($maxpage-1)."</a><a class='paginate_button' data-page='".$maxpage."' >".$maxpage."</a>";
		}
		$return_string .= $str2;
		return $return_string;
}

function get_list_misc_product_all_classify($wpdb){
	$all_array = array();
	$products = $wpdb->get_results("SELECT `title` FROM `wp_create_table` ORDER BY creat_date ASC limit 0,20");
	foreach ($products as $product) {
		$all_array[] = $product->title;
	}
	 return array_unique($all_array);
}

function get_list_misc_product_class_products($wpdb,$title){
	$products_arr = array();
	$products = $wpdb->get_results(sprintf("SELECT `catalog`,`url` FROM `_cs_misc_product_class` WHERE `class` = '%s'  ORDER BY `catalog` ASC",$title));
	foreach ($products as $product) {
		$products_arr[$product->catalog] = $product->url;
	}
	return $products_arr;
}

/*Some functions in Template*/
/*
column:当前列名称，可选值：catalog,desc,desc2,desc3
linkat:加入链接的列
content:被包含的内容
url:链接
*/
if(!function_exists('checkLink_plus')){
	function checkLink_plus($column,$linkat,$content,$url){
		if(preg_match("/\.jpg|\.jpeg|\.png|\.gif|\.bmp|\.pdf/", $url)){
			$target = '_blank';
		}else{
			$target = '_self';
		}
		if($column==$linkat and $url!=''){
			return sprintf("<a href=\"%s\" target=\"%s\">%s</a>",$url,$target,$content);
		}else{
			return sprintf("%s",$content);
		}
	}
}
?>