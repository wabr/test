<?php
require_once(dirname(__FILE__)."/../../../wp-blog-header.php");
require_once(dirname(__FILE__)."/create_table_functions.php");
foreach ($products as $product){
	$products_arr[] = array(
		'checkbox'=> sprintf("<input name=\"cat_nos[]\" type=\"checkbox\" value=\"%s\">",$product->$sort),
		'catalog'=>$product->$sort,
		'url'=>$product->$url,
		'price'=>$product->price,
	);
}

?>
<?php if(!empty($products_arr)){?>
<form action="/order/cart_add.php" method="get">
<table class="table_org">
	<tr>
		<td>Buy</td>
		<td nowrap><?php echo $sort;?></td>
		<td>price</td>
	</tr>
	<?php foreach ($products_arr as $product) { 
		if($product['catalog']!='') {?>
	<tr>
		<td><?php echo $product['checkbox']; ?></td>
		<td nowrap><?php echo checkLink_plus($sort,$sort,$product['catalog'],$product['url']); ?></td>
		<td class="text-right"><?php echo login2show('$'.$product['price']); ?></td>
	</tr>
		<?php } 
	} ?>
</table>
<table border="0" width="100%" style="margin-top:15px;">
	<tbody>
		<tr>
			<td><input border="0" src="/images/add_t_s_c.png" type="image"> <input name="prt" type="hidden" value="1"></td>
		</tr>
	</tbody>
</table>
</form>
<?php } ?>