<?php
require_once(dirname(__FILE__)."/create_table_functions.php");
global $wpdb;
?>
<h1>Other Functions</h1>
select datetable:
<select class="dt1" name="dt1" id="dt1">
	<option  value="_cs_misc_product">misc</option>
	<option value="vector">vector</option>
</select>